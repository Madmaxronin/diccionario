elementos = {"a": 1, "b": 2, "c": 3, "d": 4}

"""
elementos["nombre"] = "Cody" # Crea la llave con su valor
elementos[(1, 2, 3)] ="La llave es una tupla"

# Actualiza el valor de la llave
elementos["nombre"] = "Max"
"""

print(elementos)
print(len(elementos))